package com.infy.moviebooking.exception;

public class MovieBookingException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MovieBookingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
